# Chest-Related-Disease-Prediction-Using-Deep-Learning
 System Developed on deep learning.it enhance a solution in hospital to digitally predict results on diseases.it helps in     rural areas where lack of skilled doctors.
